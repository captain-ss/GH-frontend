import { DatePicker } from "@progress/kendo-react-dateinputs";

export default function DateComponent() {
    return (
        <>

            <div className="k-my-4">

                <DatePicker
                    format={{
                        day: "numeric",
                        year: "numeric",
                        month: "long",
                    }}
                />

            </div>

        </>
    );
}
