import React, { useEffect, useState } from 'react'
import { Table } from 'reactstrap'
import { MDBDataTable } from "mdbreact"
// Ratings
import RatingTooltip from "react-rating-tooltip"

function Reviews({ limit, admin }) {
	const [reviewsData, setReviewsData] = useState({
		columns: [
			{
				label: "Id",
				field: "id",
				sort: "asc"
			},
			{
				label: "Ratings",
				field: "rating",
				sort: "asc"
			},
			{
				label: "Review",
				field: "content",
				sort: "asc"
			},
			{
				label: "Date",
				field: "date",
				sort: "asc"
			},
			{
				label: "Status",
				field: "isPublish",
				sort: "asc"
			}
		],
		rows: [
			{
				userIcon: '/assets/user/blank-user.png',
				rating: 3,
				content: 'It allows you to keep your diet under control, particularly in terms of calorie control; You can change food every day! On Monday Indian food, on Tuesday tacos',
				date: '12/1/2020',
				isPublish: true
			},
			{
				userIcon: '/assets/user/blank-user.png',
				rating: 3,
				content: 'It allows you to keep your diet under control, particularly in terms of calorie control; You can change food every day! On Monday Indian food, on Tuesday tacos',
				date: '12/1/2020',
				isPublish: false
			},
			{
				userIcon: '/assets/user/blank-user.png',
				rating: 3,
				content: 'It allows you to keep your diet under control, particularly in terms of calorie control; You can change food every day! On Monday Indian food, on Tuesday tacos',
				date: '12/1/2020',
				isPublish: true
			},
			{
				userIcon: '/assets/user/blank-user.png',
				rating: 3,
				content: 'It allows you to keep your diet under control, particularly in terms of calorie control; You can change food every day! On Monday Indian food, on Tuesday tacos',
				date: '12/1/2020',
				isPublish: false
			},
			{
				userIcon: '/assets/user/blank-user.png',
				rating: 3,
				content: 'It allows you to keep your diet under control, particularly in terms of calorie control; You can change food every day! On Monday Indian food, on Tuesday tacos',
				date: '12/1/2020',
				isPublish: true
			},
			{
				userIcon: '/assets/user/blank-user.png',
				rating: 3,
				content: 'It allows you to keep your diet under control, particularly in terms of calorie control; You can change food every day! On Monday Indian food, on Tuesday tacos',
				date: '12/1/2020',
				isPublish: true
			},
			{
				userIcon: '/assets/user/blank-user.png',
				rating: 3,
				content: 'It allows you to keep your diet under control, particularly in terms of calorie control; You can change food every day! On Monday Indian food, on Tuesday tacos',
				date: '12/1/2020',
				isPublish: true
			},
			{
				userIcon: '/assets/user/blank-user.png',
				rating: 3,
				content: 'It allows you to keep your diet under control, particularly in terms of calorie control; You can change food every day! On Monday Indian food, on Tuesday tacos',
				date: '12/1/2020',
				isPublish: true
			}
		]
	});
  
	useEffect(() => {
		// setReviewsData();
	}, []);

	if (admin) {
		return <MDBDataTable responsive striped bordered hover entriesOptions={[5, 20, 25]} entries={5} pagesAmount={4} data={reviewsData} />
	}
  
	return (
		<ul className="reviews-list">
			{
				reviewsData?.rows?.map((review, idx) => (
					idx < limit && <li key={idx} className="review-item">
						<img src="/assets/icons/quotes.svg" alt="" className="icon-quote" />
						<div className="review-img">
							<img src={review.userIcon} alt="" className="avatar-xs rounded-circle me-2" />
						</div>
						<div className="review-content">
							<div className="reviewer">
								<p className="reviewer-name">Anonymus</p>
								<RatingTooltip
									max={5}
									key={`rating-${idx}`}
									defaultRating={review.rating}
									disabled={true}
									ActiveComponent={
										<i
											key={"active_1"}
											className="mdi mdi-star text-primary"
										/>
									}
									InActiveComponent={
										<i
											key={"active_01"}
											className="mdi mdi-star text-muted"
										/>
									}
								/>
							</div>
							<p className="reviews-text">{review.content}</p>
						</div>
					</li>
				))
			}
		</ul>
	)
}

export default Reviews