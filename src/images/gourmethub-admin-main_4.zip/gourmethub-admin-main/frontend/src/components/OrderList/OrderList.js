import React, { useEffect, useState } from 'react';
import { Table, Button } from 'reactstrap'

function OrderList(props) {
	const [orders, setOrders] = useState(null);

	useEffect(() => {
		setOrders(props.orders)
	}, [props])
	
	return (
		<div className="table-responsive">
			<Table className="table mb-0">
				<thead className="table-light">
					<tr>
						{
							orders && orders.cols.map((col, idx) => <th key={idx} scope="col">{col}</th>)
						}
					</tr>
				</thead>
				<tbody>
					{
						orders && orders.rows.map((row, idx) => <tr key={idx}>
							{row.id && <th scope="row">{row.id}</th>}
							{row.date && <td>{row.date}</td>}
							{row.mealPlan && <td>{row.mealPlan}</td>}
							{
								row.combination && <td><span className="meal">M</span><span className="meal">M</span><span className="meal">M</span><span className="snack">S</span></td>
							}
							{row.startDate && <td>{row.startDate}</td>}
							{row.duration && <td>{row.duration}</td>}
							{row.location && <td>{row.location}</td>}
							{row.amount && <td>{row.amount}</td>}
							{row.subject && <td>{row.subject}</td>}
							{row.status && <td>
								{row.status.inProgress && <span className="status in-progress">In Progress</span>}
								{row.status.notStarted && <span className="status not-started">Not Started</span>}
								{row.status.completed && <span className="status completed">Completed</span>}
								{row.status.hold && <span className="status hold">Hold</span>}
							</td>}
							{row.action && <td>
								<Button color="primary">Yes</Button>
								<Button color="danger">No</Button>
							</td>}
						</tr>)
					}
				</tbody>
			</Table>
		</div>
	);
}

export default OrderList;