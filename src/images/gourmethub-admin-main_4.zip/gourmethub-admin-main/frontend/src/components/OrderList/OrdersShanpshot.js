import React from 'react';
import { Button } from 'reactstrap';

function OrdersShanpshot({ orderDetails }) {
	const { number, status } = orderDetails;

	const handleClick = (e) => {
		const orderSnapshotCTA = document.querySelectorAll('.order-snapshot--wrapper');
		orderSnapshotCTA.forEach((obj) => {
			obj.classList.remove('active');
		})
		if (e.target.tagName !== 'button') {
			console.log('parent')
			e.target.closest('button').classList.add('active');
		}
	}

	return <Button className="order-snapshot--wrapper mb-3" data-order-status={status} onClick={handleClick}>
		<p className="order-content">
			<span className="order-no">{number}</span>
			{status === 'approved' && <span className="order-status">Approved</span>}
			{status === 'pending' && <span className="order-status">Pending Request</span>}
			{status === 'cancelled' && <span className="order-status">Cancelled</span>}
			{status === 'inactive' && <span className="order-status">Inactive</span>}
		</p>
		
		<div className={`status-icon ${status}`}>
			<img src={`/assets/icons/ico_${status}.png`} alt={`icon ${status}`} />
		</div>
	</Button>
}

export default OrdersShanpshot