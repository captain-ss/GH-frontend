import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Row, Col, Button } from 'reactstrap';

function OrderRequestItem({ status, className, orderDetail }) {
	const [ordersData, setOrdersData] = useState([]);

	return <Row className={`order-item--wrapper ${className}`}>
		<Col xs={{span: 10, offset: 2}}>
			<p className="plan-name"><img src="/assets/icons/goal.png" alt="icon goal" /> Weightloss (Vegetarian) <span className="icon-veg"><img src="/assets/icons/veg-ico.svg" alt="icon veg" /> Veg</span></p>
		</Col>
		<Col sm={6} md={4} lg={2}>
			<p className="order-no">#121</p>
		</Col>
		<Col sm={6} md={4} lg={2}>
			<p className="start-date"><img src="/assets/icons/calendar.png" alt="" /> 12/1/2022</p>
			<p className="location"><img src="/assets/icons/location.png" alt="" /> Lorem ipsum</p>
		</Col>
		<Col sm={6} md={4} lg={2}>
			<p className="gender"><img src="/assets/icons/lavatory.png" alt="" /> Female</p>
			<p className="meals-snacks"><img src="/assets/icons/food.png" alt="" /> 2 x Meals 1 x Snack</p>
		</Col>
		<Col sm={6} md={4} lg={2}>
			<p className="duration"><img src="/assets/icons/time.png" alt="" /> 5 days</p>
			<p className="days"><img src="/assets/icons/time-left.png" alt="" /> Mon Tue Fri Sat</p>
		</Col>
		<Col sm={6} md={4} lg={2}>
			<p className="amount">AED 200 <span className="discount">(Discount -100 AED)</span></p>
		</Col>
		{
			status === 'approved' && 
				<Col sm={6} md={4} lg={2}>
					<div className="actions">
						<Button className="btn-approved">Active</Button>
						{!orderDetail && <Link to="/order-request/order-detail" className="btn-next btn btn-secondary"><img src="/assets/icons/down.png" alt="icon next" /></Link>}
						<p className="order-intime">16 hours ago</p>
					</div>
				</Col>
		}
		{
			status === 'pending' && 
				<Col sm={6} md={4} lg={2}>
					<div className="actions">
						<Button><img src="/assets/icons/checked.png" alt="icon approve" /></Button>
						<Button><img src="/assets/icons/cancel.png" alt="icon cancel" /></Button>
						<p className="order-intime">16 hours ago</p>
					</div>
				</Col>
		}
		{
			status === 'cancelled' && 
				<Col sm={6} md={4} lg={2}>
					<div className="actions">
						<Button className="btn-cancelled">Approve</Button>
						<p className="order-intime">16 hours ago</p>
					</div>
				</Col>
		}
		{
			status === 'inactive' && 
				<Col sm={6} md={4} lg={2}>
					<div className="actions">
						<Button className="btn-inactive">Inactive</Button>
						<p className="order-intime">16 hours ago</p>
					</div>
				</Col>
		}
	</Row>;
}

export default OrderRequestItem;