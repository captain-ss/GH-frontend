import React from 'react'
import { Button, Modal, Input, Label } from 'reactstrap';

function GHModal({ modalScroll, setModalScroll, togScroll, label, data }) {
	return <Modal isOpen={modalScroll} toggle={togScroll} scrollable={true}>
		<div className="modal-header"> 
			<h5 className="modal-title mt-0">add iems to <span className="color-orange">{label}</span></h5>
			<button type="button" onClick={() => setModalScroll(false)} className="close" data-dismiss="modal" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>
		<div className="modal-body add-items--wrapper">
			<div className="mb-3 position-relative">
				<input className="form-control" type="search" placeholder="Search" />
				<img src="/assets/icons/search.svg" className='ico-search' />
			</div>
			<ul className="item-list--wrapper list-unstyled">
				{
					data?.map((item, idx) => <li key={`item-${idx}`} className="position-relative">
						<Input type="checkbox" className="form-check-input" id={`chk-${idx}`} />
						<Label className="form-check-label" htmlFor={`chk-${idx}`}>{item.name}</Label>
						<p className="calory">{item.cal}</p>
					</li>)
				}
			</ul>
			
			<div className="modal-footer">
				<Button color="secondary" onClick={() => setModalScroll(false)}>Close</Button>
				<Button color="primary">Save changes</Button>
			</div>
		</div>
	</Modal>;
}

export default GHModal