import React, { useState } from 'react'
import { Table, Button } from 'reactstrap';
import GHModal from 'components/GHModal/GHModal';

function MealItemsList({ items }) {
	const itemLen = items.itemList.length;
	const [modalScroll, setModalScroll] = useState(false)

	const totalItems = [
		{ name: "item 1", cal: "120" },
		{ name: "item 2", cal: "120" },
		{ name: "item 3", cal: "120" },
		{ name: "item 4", cal: "120" },
		{ name: "item 5", cal: "120" },
		{ name: "item 6", cal: "120" },
		{ name: "item 7", cal: "120" },
		{ name: "item 8", cal: "120" },
		{ name: "item 9", cal: "120" },
		{ name: "item 10", cal: "120" }
	]

	function removeBodyCss() {
		document.body.classList.add("no_padding");
	}

	function togScroll() {
		setModalScroll(!modalScroll);
		removeBodyCss();
	}

	return <div className="items-wrapper">
		<Table>
			<thead>
				<tr>
					<th colSpan={5}><img src="/assets/icons/icon-chevron.png" alt="" /> {items.label} <span className="item-no">Items ({itemLen})</span></th>
				</tr>
			</thead>
			<tbody>
				{
					items?.itemList.map((item, idx) => <tr key={idx}>
						<td><img src="/assets/icons/ico-move.png" alt="icon move" /></td>
						<td>{item.name}</td>
						<td>{item.cal}</td>
						<td>{item.price}</td>
						<td>
							<Button className="btn-action"><i className="fas fa-eye"></i></Button>
							<Button className="btn-action"><i className="fas fa-trash-alt"></i></Button>
						</td>
					</tr>)
				}
			</tbody>
		</Table>
		<Button className="meal-plan--cta" onClick={togScroll} data-toggle="modal">+ Add item</Button>
		<GHModal modalScroll={modalScroll} setModalScroll={setModalScroll} togScroll={togScroll} label={items.label} data={totalItems} />
	</div>
}

export default MealItemsList