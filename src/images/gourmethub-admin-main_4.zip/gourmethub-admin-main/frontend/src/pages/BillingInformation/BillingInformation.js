import React, { useState } from 'react';
import { Container, Row, Col, Label, Table } from 'reactstrap';
import Select from "react-select"

function BillingInformation() {
	const [locationOption, setLocation] = useState(null);
	const [monthOption, setMonth] = useState(null);
	const [history, setHistory] = useState(null);
	const kitchenLocation = [
		{
			options: [
				{ label: "Mustard", value: "Mustard" },
				{ label: "Ketchup", value: "Ketchup" },
				{ label: "Relish", value: "Relish" }
			]
		},
	];
	const selectMonth = [
		{
			options: [
				{ label: "Month", value: "Month" },
				{ label: "Ketchup", value: "Ketchup" },
				{ label: "Relish", value: "Relish" }
			]
		},
	];
	const orderHistory = [
		{
			options: [
				{ label: "Order", value: "Order" },
				{ label: "Ketchup", value: "Ketchup" },
				{ label: "Relish", value: "Relish" }
			]
		},
	];

	function handleSelectGroup(selectedGroup, group) {
		if (group === 'location') {
			setLocation(selectedGroup);
		}
		if (group === 'month') {
			setMonth(selectedGroup)
		}
		if (group === 'order') {
			setHistory(selectedGroup)
		}
	}

	return <Container className="page-content billing-information--wrapper">
		<div className="page-title-box">
			<Row className="mb-3">
				<Col md={6}>
					<h2 className="page-title">Billing Information</h2>
				</Col>
				<Col md={6}>
					<Row>
						<Col md={6}>
							<Label>Kitchen Location<sup>*</sup></Label>
							<Select value={locationOption} onChange={(e) => handleSelectGroup(e, 'location')} options={kitchenLocation} classNamePrefix="location" />
						</Col>
						<Col md={6}>
							<Label>Select Month</Label>
							<Select value={monthOption} onChange={(e) => handleSelectGroup(e, 'month')} options={selectMonth} classNamePrefix="month" />
						</Col>
					</Row>
				</Col>
			</Row>
		</div>
		<div className="snapshot">
			<h3 className="list-title">Order History</h3>
			<Row className="mb-3">
				<Col md={3} className="position-relative">
					<input className="form-control" type="search" placeholder="Search" />
					<img src="/assets/icons/search.svg" className='ico-search' />
				</Col>
				<Col md={3}>
					<Select value={history} onChange={(e) => handleSelectGroup(e, 'order')} options={orderHistory} classNamePrefix="order" />
				</Col>
			</Row>
			<div className="order-history table-responsive custom-scrollbar">
				<Table className="table mb-0">
					<thead className="table-light">
						<tr>
							<th scope="col">id</th>
							<th scope="col">Meal Plan</th>
							<th scope="col">Location</th>
							<th scope="col">Start Date</th>
							<th scope="col">End Date</th>
							<th scope="col">Renewal</th>
							<th scope="col">Payment</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td scope="row">#121</td>
							<td>Wightloss</td>
							<td>Lorem ipsum dolor sit</td>
							<td>12/1/2020</td>
							<td>12/1/2020</td>
							<td>3 months</td>
							<td>AED 224</td>
						</tr>
						<tr>
							<td scope="row">#121</td>
							<td>Wightloss</td>
							<td>Lorem ipsum dolor sit</td>
							<td>12/1/2020</td>
							<td>12/1/2020</td>
							<td>3 months</td>
							<td>AED 224</td>
						</tr>
						<tr>
							<td scope="row">#121</td>
							<td>Wightloss</td>
							<td>Lorem ipsum dolor sit</td>
							<td>12/1/2020</td>
							<td>12/1/2020</td>
							<td>3 months</td>
							<td>AED 224</td>
						</tr>
						<tr>
							<td scope="row">#121</td>
							<td>Wightloss</td>
							<td>Lorem ipsum dolor sit</td>
							<td>12/1/2020</td>
							<td>12/1/2020</td>
							<td>3 months</td>
							<td>AED 224</td>
						</tr>
						<tr>
							<td scope="row">#121</td>
							<td>Wightloss</td>
							<td>Lorem ipsum dolor sit</td>
							<td>12/1/2020</td>
							<td>12/1/2020</td>
							<td>3 months</td>
							<td>AED 224</td>
						</tr>
						<tr>
							<td scope="row">#121</td>
							<td>Wightloss</td>
							<td>Lorem ipsum dolor sit</td>
							<td>12/1/2020</td>
							<td>12/1/2020</td>
							<td>3 months</td>
							<td>AED 224</td>
						</tr>
						<tr>
							<td scope="row">#121</td>
							<td>Wightloss</td>
							<td>Lorem ipsum dolor sit</td>
							<td>12/1/2020</td>
							<td>12/1/2020</td>
							<td>3 months</td>
							<td>AED 224</td>
						</tr>
						<tr>
							<td scope="row">#121</td>
							<td>Wightloss</td>
							<td>Lorem ipsum dolor sit</td>
							<td>12/1/2020</td>
							<td>12/1/2020</td>
							<td>3 months</td>
							<td>AED 224</td>
						</tr>
						<tr>
							<td scope="row">#121</td>
							<td>Wightloss</td>
							<td>Lorem ipsum dolor sit</td>
							<td>12/1/2020</td>
							<td>12/1/2020</td>
							<td>3 months</td>
							<td>AED 224</td>
						</tr>
						<tr>
							<td scope="row">#121</td>
							<td>Wightloss</td>
							<td>Lorem ipsum dolor sit</td>
							<td>12/1/2020</td>
							<td>12/1/2020</td>
							<td>3 months</td>
							<td>AED 224</td>
						</tr>
						<tr>
							<td scope="row">#121</td>
							<td>Wightloss</td>
							<td>Lorem ipsum dolor sit</td>
							<td>12/1/2020</td>
							<td>12/1/2020</td>
							<td>3 months</td>
							<td>AED 224</td>
						</tr>
					</tbody>
				</Table>
			</div>
		</div>
	</Container>
}

export default BillingInformation