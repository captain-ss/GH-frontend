import React, { useEffect, useState } from 'react';
import { Container, Row, Col, Label, Button, ButtonGroup, Table } from 'reactstrap';
import Select from "react-select";

function LiveOrders() {
  const [locationOption, setLocation] = useState(null);
  const [orderType, setOrderType] = useState('itemType');
  const [month, setMonth] = useState('');

  useEffect(() => {
    let _month = new Date().getMonth() + 1;
    const _year = new Date().getFullYear();

    _month = _month < 10 ? `0${_month}` : _month;
    month === '' && setMonth(`${_year}-${_month}`);

  }, [month]);
  
  const kitchenLocation = [
    {
      options: [
        { label: "Mustard", value: "Mustard" },
        { label: "Ketchup", value: "Ketchup" },
        { label: "Relish", value: "Relish" }
      ]
    },
  ];
  const selectOrderType = [
    { name: 'Item Based', value: 'itemType' },
    { name: 'Order Based', value: 'orderType' }
  ];

  const liveOrderTypes = {
    tableTitle: [
      'OrderId',
      'Meal Plan',
      'Category',
      'Name',
      'Status',
      ''
    ],
    orders: [
      {
        orderId: '#121',
        mealPlan: 'Weightloss(Vegan)',
        category: [
          'Lunch',
          'Snack 1',
          'Snack 2'
        ],
        name: [
          'Yogurt with mixed berries | trail mix of nuts and dry...',
          'Yogurt with mixed berries | trail mix of nuts and dry...',
          'Yogurt with mixed berries | trail mix of nuts and dry...'
        ],
        status: {
          type: 'in-kitchen',
          name: 'In Kitchen'
        }
      },
      {
        orderId: '#122',
        mealPlan: 'Weightloss(Vegan)',
        category: [
          'Lunch',
          'Snack 1',
          'Snack 2'
        ],
        name: [
          'Yogurt with mixed berries | trail mix of nuts and dry...',
          'Yogurt with mixed berries | trail mix of nuts and dry...',
          'Yogurt with mixed berries | trail mix of nuts and dry...'
        ],
        status: {
          type: 'in-route',
          name: 'In Route'
        }
      },
      {
        orderId: '#123',
        mealPlan: 'Weightloss(Vegan)',
        category: [
          'Lunch',
          'Snack 1',
          'Snack 2'
        ],
        name: [
          'Yogurt with mixed berries | trail mix of nuts and dry...',
          'Yogurt with mixed berries | trail mix of nuts and dry...',
          'Yogurt with mixed berries | trail mix of nuts and dry...'
        ],
        status: {
          type: 'delivered',
          name: 'Delivered'
        }
      },
      {
        orderId: '#124',
        mealPlan: 'Weightloss(Vegan)',
        category: [
          'Lunch',
          'Snack 1',
          'Snack 2'
        ],
        name: [
          'Yogurt with mixed berries | trail mix of nuts and dry...',
          'Yogurt with mixed berries | trail mix of nuts and dry...',
          'Yogurt with mixed berries | trail mix of nuts and dry...'
        ],
        status: {
          type: 'in-kitchen',
          name: 'In Kitchen'
        }
      },
      {
        orderId: '#125',
        mealPlan: 'Weightloss(Vegan)',
        category: [
          'Lunch',
          'Snack 1',
          'Snack 2'
        ],
        name: [
          'Yogurt with mixed berries | trail mix of nuts and dry...',
          'Yogurt with mixed berries | trail mix of nuts and dry...',
          'Yogurt with mixed berries | trail mix of nuts and dry...'
        ],
        status: {
          type: 'in-route',
          name: 'In Route'
        }
      }
    ]
  }

  const liveItemTypes = {
    tableTitle: [
      '',
      'Name',
      'Meal Plan',
      'Quantity',
      'Order Id',
      'Status',
      ''
    ],
    orders: [
      {
        img: '/assets/food-1.png',
        name: 'Yogurt with mixed berries | trail mix of nuts and dry...',
        mealPlan: 'Weightloss(Vegan)',
        quantity: '5',
        orderId: [
          '#121',
          '#843',
          '#492',
          '#222',
          '#468'
        ],
        status: {
          type: 'in-kitchen',
          name: 'In Kitchen'
        }
      },
      {
        img: '/assets/food-1.png',
        name: 'Yogurt with mixed berries | trail mix of nuts and dry...',
        mealPlan: 'Weightloss(Vegan)',
        quantity: '5',
        orderId: [
          '#121',
          '#843',
          '#492',
          '#222',
          '#468'
        ],
        status: {
          type: 'in-route',
          name: 'In Route'
        }
      },
      {
        img: '/assets/food-1.png',
        name: 'Yogurt with mixed berries | trail mix of nuts and dry...',
        mealPlan: 'Weightloss(Vegan)',
        quantity: '5',
        orderId: [
          '#121',
          '#843',
          '#492',
          '#222',
          '#468'
        ],
        status: {
          type: 'delivered',
          name: 'Delivered'
        }
      },
      {
        img: '/assets/food-1.png',
        name: 'Yogurt with mixed berries | trail mix of nuts and dry...',
        mealPlan: 'Weightloss(Vegan)',
        quantity: '5',
        orderId: [
          '#121',
          '#843',
          '#492',
          '#222',
          '#468'
        ],
        status: {
          type: 'in-kitchen',
          name: 'In Kitchen'
        }
      },
      {
        img: '/assets/food-1.png',
        name: 'Yogurt with mixed berries | trail mix of nuts and dry...',
        mealPlan: 'Weightloss(Vegan)',
        quantity: '5',
        orderId: [
          '#121',
          '#843',
          '#492',
          '#222',
          '#468'
        ],
        status: {
          type: 'in-route',
          name: 'In Route'
        }
      }
    ]
  }
  
  function handleSelectGroup(selectedGroup, group) {
    if (group === 'location') {
      setLocation(selectedGroup);
    }
    if (group === 'month') {
      setMonth(selectedGroup);
    }
  }

  function returnOrderStatus(orderStatus) {
    let statusInfo = '';
    if(orderStatus === 'in-kitchen') {
      statusInfo = 'bg-success'
    } else if(orderStatus === 'in-route') {
      statusInfo = 'bg-orange'
    } else if(orderStatus === 'delivered') {
      statusInfo = 'bg-dark'
    }

    return statusInfo;
  }

  return <Container className="page-content order-request--wrapper">
    <div className="page-title-box">
      <Row className="mb-3">
        <Col md={6}>
          <h2 className="page-title">Live Orders</h2>
        </Col>
        <Col md={3}></Col>
        <Col md={3}>
          <Label>Kitchen Location<sup>*</sup></Label>
          <Select value={locationOption} onChange={(e) => handleSelectGroup(e, 'location')} options={kitchenLocation} classNamePrefix="location" />
        </Col>
      </Row>
      <Row>
        <Col className="order-type--selection">
          <ButtonGroup>
            {
              selectOrderType.map((order, idx) => <Button key={`orderType-${idx}`} color="outline" onClick={() => setOrderType(order.value)} active={orderType === order.value}>{order.name}</Button>)
            }
          </ButtonGroup>
        </Col>
      </Row>
    </div>

    {/* <div className="month-selection mb-3">
      <Row>
        <Col md={2}>
          <div className="month-wrapper">
            <input name="month" id="month" className="form-control month" type="month" value={month} onChange={e => setMonth(e.target.value)} />
          </div>
        </Col>
      </Row>
      <Row>
        <Col xs={12}>
          
        </Col>
      </Row>
    </div>*/}
    
    <div className="table-responsive">
    {
        orderType === 'itemType' && 
        <Table className="gh-order--table table table-striped mb-0">
          <thead className="table-light">
            <tr>
            {
              liveItemTypes.tableTitle.map((heading, idx) => <th scope="col" key={`heading-${idx}`}>{heading}</th>)
            }
            </tr>
          </thead>
          <tbody>
            {
              liveItemTypes.orders.map((item, idx) => <tr key={`order-${idx}`}>
                <td scope="row">
                  <img src={item.img} alt="Food Image" />
                </td>
                <td>
                  <ul className="gh-order--item-list list-unstyled">
                    <li>{item.name}</li>
                  </ul>
                </td>
                <td>{item.mealPlan}</td>
                <td className="text-center text-orange">{item.quantity}</td>
                <td>
                  {
                    item.orderId.map((order, idx) => <span key={`category-${idx}`}>{order}{idx === item.orderId.length - 1 ? '':','} </span>)
                  }
                </td>
                <td>
                  <span className={"gh-order--item-status d-block text-white text-center " + (returnOrderStatus(item.status.type))}>{item.status.name}</span>
                </td>
                <td><a href="#">...</a></td>
              </tr>)
            }
          </tbody>
        </Table>
      }
      {
        orderType === 'orderType' && 
        <Table className="gh-order--table table table-striped mb-0">
          <thead className="table-light">
            <tr>
            {
              liveOrderTypes.tableTitle.map((heading, idx) => <th scope="col" key={`heading-${idx}`}>{heading}</th>)
            }
            </tr>
          </thead>
          <tbody>
            {
              liveOrderTypes.orders.map((order, idx) => <tr key={`order-${idx}`}>
                <td scope="row" className="text-orange">{order.orderId}</td>
                <td>{order.mealPlan}</td>
                <td>
                  <ul className="list-unstyled">
                    {
                      order.category.map((cat, idx) => <li key={`category-${idx}`}>{cat}</li>)
                    }
                  </ul>
                </td>
                <td>
                  <ul className="gh-order--item-list list-unstyled">
                    {
                      order.name.map((name, idx) => <li key={`category-${idx}`}>{name}</li>)
                    }
                  </ul>
                </td>
                <td>
                <span className={"gh-order--item-status d-block text-white text-center " + (returnOrderStatus(order.status.type))}>{order.status.name}</span>
                </td>
                <td><a href="#">...</a></td>
              </tr>)
            }
          </tbody>
        </Table>
      }
    </div>
  </Container>;
}

export default LiveOrders;