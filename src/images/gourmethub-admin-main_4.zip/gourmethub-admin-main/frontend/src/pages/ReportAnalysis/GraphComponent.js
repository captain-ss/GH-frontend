import React, { Component } from "react"
import MetaTags from "react-meta-tags"
import PieChart from "../AllCharts/chartist/piechart"
import BarApexChart from "../AllCharts/apex/barchart"

import {
  Card,
  CardBody,
  CardHeader,
  CardSubtitle,
  CardText,
  CardTitle,
  Col,
  Table,
  Collapse,
  Container,
  Label,
  Nav,
  NavItem,
  NavLink,
  Row,
  TabContent,
  TabPane,
} from "reactstrap"
import Select from "react-select"

import { Link } from "react-router-dom"

//Import Breadcrumb
import Breadcrumbs from "../../components/Common/Breadcrumb"

import classnames from "classnames"

class GraphComponent extends Component {
  constructor(props) {
    super(props)
    this.state = {
      activeTab: "1",
      activeTab1: "5",
      activeTab2: "9",
      activeTab3: "13",
      verticalActiveTab: "1",
      customActiveTab: "1",
      customActiveTab2: "1",
      customActiveTab3: "1",
      activeTabJustify: "5",
      col1: true,
      col2: false,
      col3: false,
      col5: true,
      col6: true,
      col7: true,
      col8: true,
      col9: true,
      col10: false,
      col11: false,
	  SelectMonth:[
		{ label: "Month", value: "Month" },
		{ label: "Ketchup", value: "Ketchup" },
		{ label: "Relish", value: "Relish" }
	  ],
      GrossPricing: [
        {
          img: "",
          name: "Fruit and nuts | coconut milk chai seeds pudding",
          itemCode: "AED 120",
          soldPieaces: "230",
        },
        {
          img: "",
          name: "Fruit and nuts | coconut milk chai seeds pudding",
          itemCode: "AED 120",
          soldPieaces: "230",
        },
        {
          img: "",
          name: "Fruit and nuts | coconut milk chai seeds pudding",
          itemCode: "AED 120",
          soldPieaces: "230",
        },
        {
          img: "",
          name: "Fruit and nuts | coconut milk chai seeds pudding",
          itemCode: "AED 120",
          soldPieaces: "230",
        },
        {
          img: "",
          name: "Fruit and nuts | coconut milk chai seeds pudding",
          itemCode: "AED 120",
          soldPieaces: "230",
        },
      ],
      GrossProfit: [
        {
          name: "Weightloss | vegan ",
          itemCode: "AED 120",
          soldPieaces: "230",
        },
        {
          name: "Weightloss | vegan ",
          itemCode: "AED 120",
          soldPieaces: "230",
        },
        {
          name: "Weightloss | vegan ",
          itemCode: "AED 120",
          soldPieaces: "230",
        },
        {
          name: "Weightloss | vegan ",
          itemCode: "AED 120",
          soldPieaces: "230",
        },
        {
          name: "Weightloss | vegan ",
          itemCode: "AED 120",
          soldPieaces: "230",
        },
      ],
    }

    this.toggle = this.toggle.bind(this)
    this.toggle1 = this.toggle1.bind(this)

    this.t_col1 = this.t_col1.bind(this)
    this.t_col2 = this.t_col2.bind(this)
    this.t_col3 = this.t_col3.bind(this)
    this.t_col5 = this.t_col5.bind(this)
    this.t_col6 = this.t_col6.bind(this)
    this.t_col7 = this.t_col7.bind(this)
    this.t_col8 = this.t_col8.bind(this)
    this.t_col9 = this.t_col9.bind(this)
    this.t_col10 = this.t_col10.bind(this)
    this.t_col11 = this.t_col11.bind(this)

    this.toggle2 = this.toggle2.bind(this)
    this.toggle3 = this.toggle3.bind(this)

    this.toggleVertical = this.toggleVertical.bind(this)
    this.toggleCustom = this.toggleCustom.bind(this)
  }

  t_col1() {
    this.setState({ col1: !this.state.col1 })
  }

  t_col2() {
    this.setState({ col2: !this.state.col2 })
  }

  t_col3() {
    this.setState({ col3: !this.state.col3 })
  }

  t_col5() {
    this.setState({ col5: !this.state.col5 })
  }

  t_col6() {
    this.setState({ col6: !this.state.col6 })
  }

  t_col7() {
    this.setState({ col7: !this.state.col7 })
  }

  t_col8() {
    this.setState({
      col6: !this.state.col6,
      col7: !this.state.col7,
    })
  }

  t_col9() {
    this.setState({ col9: !this.state.col9 })
  }

  t_col10() {
    this.setState({ col10: !this.state.col10 })
  }

  t_col11() {
    this.setState({ col11: !this.state.col11 })
  }

  toggle(tab) {
    if (this.state.activeTab !== tab) {
      this.setState({
        activeTab: tab,
      })
    }
  }

  toggle1(tab) {
    if (this.state.activeTab1 !== tab) {
      this.setState({
        activeTab1: tab,
      })
    }
  }

  toggle2(tab) {
    if (this.state.activeTab2 !== tab) {
      this.setState({
        activeTab2: tab,
      })
    }
  }

  toggle3(tab) {
    if (this.state.activeTab3 !== tab) {
      this.setState({
        activeTab3: tab,
      })
    }
  }

  toggleVertical(tab) {
    if (this.state.verticalActiveTab !== tab) {
      this.setState({
        verticalActiveTab: tab,
      })
    }
  }

  toggleCustom(tab) {
    if (this.state.customActiveTab !== tab) {
      this.setState({
        customActiveTab: tab,
      })
    }
  }

  toggleCustom2(tab) {
    if (this.state.customActiveTab2 !== tab) {
      this.setState({
        customActiveTab2: tab,
      })
    }
  }

  toggleCustom3(tab) {
    if (this.state.customActiveTab3 !== tab) {
      this.setState({
        customActiveTab3: tab,
      })
    }
  }

  render() {
    console.log(this.state.GrossPricing)
    return (
      <React.Fragment>
        
          <Row>
            <Col lg={6}>
              <Card>
                <CardBody>
                  <CardTitle className="h4">Meal Plan Breakdown</CardTitle>

                  <Nav tabs className="nav-tabs-custom">
                    <NavItem>
                      <NavLink
                        style={{ cursor: "pointer" }}
                        className={classnames({
                          active: this.state.customActiveTab3 === "1",
                        })}
                        onClick={() => {
                          this.toggleCustom3("1")
                        }}
                      >
                        <span className="d-none d-sm-block">Items sold</span>
                      </NavLink>
                    </NavItem>
                    <NavItem>
                      <NavLink
                        style={{ cursor: "pointer" }}
                        className={classnames({
                          active: this.state.customActiveTab3 === "2",
                        })}
                        onClick={() => {
                          this.toggleCustom3("2")
                        }}
                      >
                        <span className="d-none d-sm-block">Profit</span>
                      </NavLink>
                    </NavItem>
                  </Nav>

                  <TabContent
                    activeTab={this.state.customActiveTab3}
                    className="p-3 text-muted"
                  >
                    <TabPane tabId="1">
                      <Row>
                        <Col sm="12">
                          <CardText className="mb-0">
                            Raw denim you probably haven't heard of them jean
                            shorts Austin. Nesciunt tofu stumptown aliqua, retro
                            synth master cleanse. Mustache cliche tempor,
                            williamsburg carles vegan helvetica. Reprehenderit
                            butcher retro keffiyeh dreamcatcher synth. Cosby
                            sweater eu banh mi, qui irure terry richardson ex
                            squid. Aliquip placeat salvia cillum iphone. Seitan
                            aliquip quis cardigan american apparel, butcher
                            voluptate nisi qui.
                          </CardText>
                        </Col>
                      </Row>
                    </TabPane>
                    <TabPane tabId="2">
                      <Row>
                        <Col sm="12" className="pie-chart-in-report-analysis">
							
                          <Row className="justify-content-center">
						  <Col sm={8}>
							<PieChart />
							</Col>
                            <Col sm={4}>
                              <div className="d-flex align-items-center mb-3 ">
                                <div className="color-box-green"></div>
								<div className="char-box-value">
									<h5 className="mb-0">16%</h5>
									<span>Weightloss -vegan</span>
								</div>
                                
                              </div>
                            
							  <div className="d-flex align-items-center mb-3 ">
                                <div className="color-box-orange"></div>
								<div className="char-box-value">
									<h5 className="mb-0">20%</h5>
									<span>Moms to be - non veg</span>
								</div>
                                
                              </div>
                            
                                <div className="d-flex align-items-center mb-3 ">
                                <div className="color-box-pink"></div>
								<div className="char-box-value">
									<h5 className="mb-0">30%</h5>
									<span>Muscle Gain - veg</span>
								</div>
                                
                              </div>
							  <div className="d-flex align-items-center mb-3 ">
                                <div className="color-box-ace"></div>
								<div className="char-box-value">
									<h5 className="mb-0">45%</h5>
									<span>Lean - keto</span>
								</div>
                                
                              </div>
                            </Col>
                          </Row>
                          
                        </Col>
                      </Row>
                    </TabPane>
                  </TabContent>
                </CardBody>
              </Card>
            </Col>
            <Col lg={6}>
              <Card>
                <CardBody>
					<Row className="justify-content-between">
						<Col sm={6}>
						<CardTitle className="h4">Sales per month</CardTitle>
						</Col>
						<Col sm={6}>
						
							<Select options={this.state.SelectMonth} classNamePrefix="month" />
						</Col>
					</Row>
                  

                  <BarApexChart />
				  <div className="d-flex justify-content-around pie-chart-in-report-analysis ">
				  <div className="d-flex align-items-center mb-3 ">
                                <div className="color-box-green"></div>
								<div className="char-box-value">
									
									<span>New customers</span>
								</div>
                                
                              </div>
                            
							  <div className="d-flex align-items-center mb-3 ">
                                <div className="color-box-orange"></div>
								<div className="char-box-value">
									
									<span>Renewals</span>
								</div>
                                
                              </div>
                            
                                <div className="d-flex align-items-center mb-3 ">
                                <div className="color-box-gray"></div>
								<div className="char-box-value">
									
									<span>Cancelled </span>
								</div>
                                
                              </div>
				  </div>
				 
                </CardBody>
              </Card>
            </Col>
          </Row>
          <Row>
            <Col lg={6}>
              <Card>
                <CardBody>
                  <CardTitle className="h4">Top Selling items</CardTitle>

                  <Nav tabs className="nav-tabs-custom">
                    <NavItem>
                      <NavLink
                        style={{ cursor: "pointer" }}
                        className={classnames({
                          active: this.state.customActiveTab === "1",
                        })}
                        onClick={() => {
                          this.toggleCustom("1")
                        }}
                      >
                        <span className="d-none d-sm-block">Items sold</span>
                      </NavLink>
                    </NavItem>
                    <NavItem>
                      <NavLink
                        style={{ cursor: "pointer" }}
                        className={classnames({
                          active: this.state.customActiveTab === "2",
                        })}
                        onClick={() => {
                          this.toggleCustom("2")
                        }}
                      >
                        <span className="d-none d-sm-block">Gross pricing</span>
                      </NavLink>
                    </NavItem>
                  </Nav>

                  <TabContent
                    activeTab={this.state.customActiveTab}
                    className="p-3 text-muted"
                  >
                    <TabPane tabId="1">
                      <Row>
                        <Col sm="12">
                          <CardText className="mb-0">
                            Raw denim you probably haven't heard of them jean
                            shorts Austin. Nesciunt tofu stumptown aliqua, retro
                            synth master cleanse. Mustache cliche tempor,
                            williamsburg carles vegan helvetica. Reprehenderit
                            butcher retro keffiyeh dreamcatcher synth. Cosby
                            sweater eu banh mi, qui irure terry richardson ex
                            squid. Aliquip placeat salvia cillum iphone. Seitan
                            aliquip quis cardigan american apparel, butcher
                            voluptate nisi qui.
                          </CardText>
                        </Col>
                      </Row>
                    </TabPane>
                    <TabPane tabId="2">
                      <Row>
                        <Col sm="12">
                          <div className="table-responsive">
                            <Table className="mb-0 table-borderless">
                              <thead className="table-light">
                                {/* <tr>
                  <th scope="col">Discount Name</th>
                  <th scope="col">Discount Code</th>
                  <th scope="col">Meal Plan</th>
                  <th scope="col">Start Date </th>
                  <th scope="col">Duration</th>
                  <th scope="col">Discount offered</th>
                  <th scope="col">Total sales</th>
                </tr> */}
                              </thead>
                              <tbody>
                                {this.state.GrossPricing.map((data, index) => {
                                  return (
                                    <tr>
                                      <td>
                                        <img
                                          src="/assets/meal-item.png"
                                          className="avatar-sm rounded-circle float-start me-3"
                                          alt=""
                                        />
                                      </td>
                                      <td>{data.name}</td>
                                      <td className="text-orange">
                                        {data.itemCode}
                                      </td>
                                      <td className="text-orange">
                                        {data.soldPieaces} sold
                                      </td>
                                    </tr>
                                  )
                                })}
                              </tbody>
                            </Table>
                          </div>
                        </Col>
                      </Row>
                    </TabPane>
                  </TabContent>
                </CardBody>
              </Card>
            </Col>
            <Col lg={6}>
              <Card>
                <CardBody>
                  <CardTitle className="h4">Meal Plans</CardTitle>

                  <Nav tabs className="nav-tabs-custom">
                    <NavItem>
                      <NavLink
                        style={{ cursor: "pointer" }}
                        className={classnames({
                          active: this.state.customActiveTab2 === "1",
                        })}
                        onClick={() => {
                          this.toggleCustom2("1")
                        }}
                      >
                        <span className="d-none d-sm-block">Most liked</span>
                      </NavLink>
                    </NavItem>
                    <NavItem>
                      <NavLink
                        style={{ cursor: "pointer" }}
                        className={classnames({
                          active: this.state.customActiveTab2 === "2",
                        })}
                        onClick={() => {
                          this.toggleCustom2("2")
                        }}
                      >
                        <span className="d-none d-sm-block">Gross Profit</span>
                      </NavLink>
                    </NavItem>
                  </Nav>

                  <TabContent
                    activeTab={this.state.customActiveTab2}
                    className="p-3 text-muted"
                  >
                    <TabPane tabId="1">
                      <Row>
                        <Col sm="12">
                          <CardText className="mb-0">
                            Raw denim you probably haven't heard of them jean
                            shorts Austin. Nesciunt tofu stumptown aliqua, retro
                            synth master cleanse. Mustache cliche tempor,
                            williamsburg carles vegan helvetica. Reprehenderit
                            butcher retro keffiyeh dreamcatcher synth. Cosby
                            sweater eu banh mi, qui irure terry richardson ex
                            squid. Aliquip placeat salvia cillum iphone. Seitan
                            aliquip quis cardigan american apparel, butcher
                            voluptate nisi qui.
                          </CardText>
                        </Col>
                      </Row>
                    </TabPane>
                    <TabPane tabId="2">
                      <Row>
                        <Col sm="12">
                          <Table className="mb-0 table-borderless">
                            <thead className="table-light"></thead>
                            <tbody>
                              {this.state.GrossProfit.map((data, index) => {
                                return (
                                  <tr>
                                    <td>{data.name}</td>
                                    <td className="text-orange">
                                      {data.itemCode}
                                    </td>
                                    <td className="text-orange">
                                      {data.soldPieaces} sold
                                    </td>
                                  </tr>
                                )
                              })}
                            </tbody>
                          </Table>
                        </Col>
                      </Row>
                    </TabPane>
                  </TabContent>
                </CardBody>
              </Card>
            </Col>
          </Row>
      
      </React.Fragment>
    )
  }
}

export default GraphComponent
