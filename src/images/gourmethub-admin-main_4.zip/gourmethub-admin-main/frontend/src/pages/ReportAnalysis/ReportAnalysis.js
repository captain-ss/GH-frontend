import React, { useState } from "react"
import {
  Container,
  Row,
  Col,
  Label,
  Table,
  Button,
  CardBody,
  Card,
  CardTitle,
} from "reactstrap"
import Select from "react-select"
import { Link } from "react-router-dom"
import Rating from "react-rating"
import RatingTooltip from "react-rating-tooltip"
import GraphComponent from "./GraphComponent"
// import charts
import profitImage from "../../assets/images/profits 1.png"
import deleteImage from "../../assets/images/delete 1.png"
import earningsImage from "../../assets/images/earnings 1.png"
import hiredImage from "../../assets/images/hired 1.png"
import onlineOrder from "../../assets/images/online-order (1) 3.png"

import PieChart from "../AllCharts/chartist/piechart"
import LineBar from "../AllCharts/echart/linebarchart"

import "chartist/dist/scss/chartist.scss"
import "../../assets/scss/chartist.scss"
function ReportAnalysis() {
  const [def, setdef] = useState("")
  const [toggleCustom, setToggleCustom] = useState("1")
  const starStyle = {}

  const TableData = [
    {
      discountName: "Healthy Tuesday",
      discountCode: "UP50LIV",
      mealPlan: "Weightloss(non-veg)",
      startDate: "12/1/2022",
      duration: "01 Month",
      discountOffered: "12%",
      totalSales: "170",
    },
    {
      discountName: "Healthy Tuesday",
      discountCode: "UP50LIV",
      mealPlan: "Weightloss(non-veg)",
      startDate: "12/1/2022",
      duration: "01 Month",
      discountOffered: "12%",
      totalSales: "170",
    },
    {
      discountName: "Healthy Tuesday",
      discountCode: "UP50LIV",
      mealPlan: "Weightloss(non-veg)",
      startDate: "12/1/2022",
      duration: "01 Month",
      discountOffered: "12%",
      totalSales: "170",
    },
    {
      discountName: "Healthy Tuesday",
      discountCode: "UP50LIV",
      mealPlan: "Weightloss(non-veg)",
      startDate: "12/1/2022",
      duration: "01 Month",
      discountOffered: "12%",
      totalSales: "170",
    },
    {
      discountName: "Healthy Tuesday",
      discountCode: "UP50LIV",
      mealPlan: "Weightloss(non-veg)",
      startDate: "12/1/2022",
      duration: "01 Month",
      discountOffered: "12%",
      totalSales: "170",
    },
  ]

  return (
    <Container className="page-content order-request--wrapper">
      <div className="page-content">
        <section className="company-summary-section ">
          <Row>
            <Col md={3}>
              <div className="summary-box">
                <div className="summary-image">
                  <img className="img-fluid" src={earningsImage}></img>
                </div>
                <div className="summary-headline">
                  <h5>AED 20,000</h5>
                  <span>Total Earning</span>
                </div>
              </div>
            </Col>
            <Col md={3}>
              <div className="summary-box">
                <div className="summary-image">
                  <img className="img-fluid" src={profitImage}></img>
                </div>
                <div className="summary-headline">
                  <h5>AED 17,200</h5>
                  <span>Gross profit</span>
                </div>
              </div>
            </Col>

            <Col md={3}>
              <div className="summary-box ">
                <div className="summary-image">
                  <img className="img-fluid" src={onlineOrder}></img>
                </div>
                <div className="summary-headline">
                  <h5>1299</h5>
                  <span>Total Orders</span>
                </div>
              </div>
            </Col>

            <Col md={3}>
              <div className="summary-box d-flex flex-column ">
                <div className="d-flex align-items-center">
                  <h5 className="font-16 m-b-15 mb-0 mx-2">4.2</h5>
                  <RatingTooltip
                    max={5}
                    onChange={rate => {
                      setdef(rate)
                    }}
                    ActiveComponent={
                      <i
                        key={"active_1"}
                        className="mdi mdi-star text-primary"
                        style={starStyle}
                      />
                    }
                    InActiveComponent={
                      <i
                        key={"active_01"}
                        className="mdi mdi-star-outline text-muted"
                        style={starStyle}
                      />
                    }
                  />{" "}
                  <span>{def}</span>
                </div>

                <div className="summary-headline">
                  <span>Customer Satisfaction</span>
                </div>
              </div>
            </Col>
            <Col md={3}>
              <div className="summary-box ">
                <div className="summary-image">
                  <img className="img-fluid" src={earningsImage}></img>
                </div>
                <div className="summary-headline">
                  <h5>30,000</h5>
                  <span>Active Users</span>
                </div>
              </div>
            </Col>

            <Col md={3}>
              <div className="summary-box ">
                <div className="summary-image">
                  <img className="img-fluid" src={deleteImage}></img>
                </div>
                <div className="summary-headline">
                  <h5>AED 20,000</h5>
                  <span>Churn Rate</span>
                </div>
              </div>
            </Col>
          </Row>
        </section>

        
        <GraphComponent />
        <Card>
          <CardBody>
            <CardTitle className="h4">Discount Analysis</CardTitle>
            <div className="table-responsive">
              <Table className="mb-0 table-borderless">
                <thead className="table-light">
                  <tr>
                    <th scope="col">Discount Name</th>
                    <th scope="col">Discount Code</th>
                    <th scope="col">Meal Plan</th>
                    <th scope="col">Start Date </th>
                    <th scope="col">Duration</th>
                    <th scope="col">Discount offered</th>
                    <th scope="col">Total sales</th>
                  </tr>
                </thead>
                <tbody>
                  {TableData.map((data, index) => {
                    return (
                      <tr>
                        <td>{data.discountName}</td>
                        <td>{data.discountCode}</td>
                        <td>{data.mealPlan}</td>
                        <td>{data.startDate}</td>
                        <td>{data.duration}</td>
                        <td>{data.discountOffered}</td>
                        <td className="text-orange">{data.totalSales}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </Table>
            </div>
          </CardBody>
        </Card>
      </div>
    </Container>
  )
}

export default ReportAnalysis
