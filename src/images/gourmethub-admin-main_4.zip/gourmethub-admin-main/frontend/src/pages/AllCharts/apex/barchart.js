import React, { Component } from 'react';
import ReactApexChart from 'react-apexcharts';

class barchart extends Component {
    constructor(props) {
        super(props);

        this.state = {
            options: {
                chart: {
                    toolbar: {
                        show: false,
                    },
                },
                colors: ['#C4C4C4', '#EB5933',  '#2FAC66' ],
                plotOptions: {
                    bar: {  
                        columnWidth: '45%',
                        dataLabels: {
                            show: false
                        },

                    },
                },
                legend: {
                    show: false
                },
                dataLabels: {
                    enabled: false,
                },
                grid: {
                    borderColor: '#f8f8fa',
                    row: {
                        colors: ['transparent', 'transparent'], // takes an array which will be repeated on columns
                        opacity: 0.5
                    },
                },
                stroke: {
                    show: true,
                    width: 1.5,
                    colors: ['#fff']
                },
                xaxis: {
                    categories: ["jan", "feb", "mar", "apr", "may", "jun"],
                    axisBorder: {
                        show: false
                    },
                    axisTicks: {
                        show: false
                    }
                }
            },
            series: [{
                name: 'Series A',
                data: [10, 10, 10, 10, 10, 10,]
            }, {
                name: 'Series B',
                data: [30, 30, 30, 30, 30, 30 ]
            },
            {
                name: 'Series C',
                data: [40, 40, 40, 40, 40, 40]
            },
        ],
            
        }
    }
    render() {
        return (
            <React.Fragment>
                <ReactApexChart options={this.state.options} series={this.state.series} type="bar" height="290" />
            </React.Fragment>
        );
    }
}

export default barchart;