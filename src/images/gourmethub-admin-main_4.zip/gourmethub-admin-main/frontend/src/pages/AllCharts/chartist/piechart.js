import React, { Component } from "react";
import ChartistGraph from "react-chartist";

class piechart extends Component {
  render() {
    var pieChartData = {
      series: [4, 3, 3, 5],
      labels: ["30%", "20%", "20%", "45%"]
    };
    var pieChartOptions = {
      showLabel: true
    };
    return (
      <React.Fragment>
        <ChartistGraph
          data={pieChartData}
          options={pieChartOptions}
          style={{ height: "300px" }}
          type={"Pie"}
        />
      </React.Fragment>
    );
  }
}

export default piechart;
