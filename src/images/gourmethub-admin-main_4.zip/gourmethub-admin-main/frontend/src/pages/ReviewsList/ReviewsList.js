import React, { useState } from 'react'
import { Container, Row, Col, Label } from 'reactstrap'
import Select from "react-select"
import Reviews from 'components/Reviews/Reviews'

function ReviewsList() {
	const [selectedGroup, setselectedGroup] = useState(null);
	const optionGroup = [
		{
			options: [
				{ label: "Mustard", value: "Mustard" },
				{ label: "Ketchup", value: "Ketchup" },
				{ label: "Relish", value: "Relish" }
			]
		},
	]

	function handleSelectGroup(selectedGroup) {
		setselectedGroup(selectedGroup);
	}

	return <Container className="page-content review-list">
		<div className="page-title-box">
			<Row>
				<Col md={6} className="mb-3">
					<h2 className="page-title">Reviews</h2>
				</Col>
				<Col md={6} className="mb-3">
					<Label>Kitchen Location<sup>*</sup></Label>
					<Select value={selectedGroup} onChange={handleSelectGroup} options={optionGroup} classNamePrefix="select2-selection" />
				</Col>
			</Row>
			<div className="snapshot">
				<h3 className="list-title">Lost of Reviews</h3>
				<Reviews admin={true} />
			</div>
		</div>
	</Container>
}

export default ReviewsList