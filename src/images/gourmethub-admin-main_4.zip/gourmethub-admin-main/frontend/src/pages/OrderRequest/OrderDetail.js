import React from 'react'
import { Link } from 'react-router-dom'
import { Container, Row, Col } from 'reactstrap'
import OrderRequestItem from 'components/OrderList/OrderRequestItem'

function OrderDetail() {
	// const history = useHistory();

	// const handleHistory = () => {
	// 	history.push('/order-request');
	// }

	return <Container className="page-content order-request--wrapper">
		<div className="page-title-box">
			<Row className="mb-3">
				<Col md={6}>
					<Link to="/order-request" className="page-title"><img src="/assets/icons/arrow-left.svg" alt="icon left" /> Order #{121}</Link>
				</Col>
			</Row>
		</div>
		<OrderRequestItem status="approved" className="order-detail--snapshot" orderDetail={true} />

		<div className="meal-display">
			<div className="meal-type--wrapper">
				<p className="className"><img src="/assets/icons/ico_breakfast.svg" alt="icon breakfast" /> Breakfast</p>
				<div className="meal-type--detail">
					<img src="/assets/meal-item.png" alt="" className="order-detail--image avatar-lg rounded-circle float-start me-3" />
					<p className="meal-type--title"><img src="/assets/icons/veg-ico.svg" alt="icon veg" /> Granola bowl with blueberries | cut fresh fruits</p>
				</div>
			</div>
			<div className="meal-type--wrapper">
				<p className="className"><img src="/assets/icons/ico_lunch.svg" alt="icon lunch" /> Lunch</p>
				<div className="meal-type--detail">
					<img src="/assets/meal-item.png" alt="" className="order-detail--image avatar-lg rounded-circle float-start me-3" />
					<p className="meal-type--title"><img src="/assets/icons/non-veg-ico.svg" alt="icon non-veg" /> Sunny Side-up Egg | chicken salad</p>
				</div>
			</div>
			<div className="meal-type--wrapper">
				<p className="className"><img src="/assets/icons/ico_dinner.svg" alt="icon dinner" /> Dinner</p>
				<div className="meal-type--detail">
					<img src="/assets/meal-item.png" alt="" className="order-detail--image avatar-lg rounded-circle float-start me-3" />
					<p className="meal-type--title"><img src="/assets/icons/non-veg-ico.svg" alt="icon non-veg" /> Lamb Rogan Josh (Persian Lamb) | pita bread</p>
				</div>
			</div>
			<div className="meal-type--wrapper">
				<p className="className"><img src="/assets/icons/ico_breakfast.svg" alt="icon snack" /> Snack 1</p>
				<div className="meal-type--detail">
					<img src="/assets/meal-item.png" alt="" className="order-detail--image avatar-lg rounded-circle float-start me-3" />
					<p className="meal-type--title"><img src="/assets/icons/veg-ico.svg" alt="icon veg" /> Roasted Chickpeas | Kale Juice</p>
				</div>
			</div>
			<div className="meal-type--wrapper">
				<p className="className"><img src="/assets/icons/ico_breakfast.svg" alt="icon snack" /> Snack 2</p>
				<div className="meal-type--detail">
					<img src="/assets/meal-item.png" alt="" className="order-detail--image avatar-lg rounded-circle float-start me-3" />
					<p className="meal-type--title"><img src="/assets/icons/veg-ico.svg" alt="icon veg" /> Banana Penut butter toast | Orange smoothie</p>
				</div>
			</div>
		</div>

		<div className="additional-wrapper">
			<h3 className="additional-title">Additional Comments:</h3>
			<p className="additional-note">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Blanditiis aperiam fuga laboriosam eos obcaecati maxime libero facilis nemo? Nam inventore sunt repellendus, illo soluta quasi, commodi quis blanditiis debitis incidunt nulla accusamus? Rem neque in perspiciatis. Molestias optio, reiciendis recusandae sunt, magni eius assumenda cum sapiente doloribus, labore sit praesentium.</p>
		</div>
	</Container>
}

export default OrderDetail