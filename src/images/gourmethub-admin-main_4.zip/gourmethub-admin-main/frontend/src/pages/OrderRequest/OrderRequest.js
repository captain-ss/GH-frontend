import React, { useState } from 'react';
import { Container, Row, Col, Label } from 'reactstrap';
import Select from "react-select"
import OrdersShanpshot from '../../components/OrderList/OrdersShanpshot'
import OrderRequestItem from '../../components/OrderList/OrderRequestItem'

function OrderRequest() {
	const [locationOption, setLocation] = useState(null);
	const [monthOption, setMonth] = useState(null);
	
	const kitchenLocation = [
		{
			options: [
				{ label: "Mustard", value: "Mustard" },
				{ label: "Ketchup", value: "Ketchup" },
				{ label: "Relish", value: "Relish" }
			]
		},
	];
	const selectMonth = [
		{
			options: [
				{ label: "Month", value: "Month" },
				{ label: "Ketchup", value: "Ketchup" },
				{ label: "Relish", value: "Relish" }
			]
		},
	];

	function handleSelectGroup(selectedGroup, group) {
		if (group === 'location') {
			setLocation(selectedGroup);
		}
		if (group === 'month') {
			setMonth(selectedGroup);
		}
	}

	return <Container className="page-content order-request--wrapper">
		<div className="page-title-box">
			<Row className="mb-3">
				<Col md={6}>
					<h2 className="page-title">Order Request</h2>
				</Col>
				<Col md={6}>
					<Row>
						<Col md={6}>
							<Label>Kitchen Location<sup>*</sup></Label>
							<Select value={locationOption} onChange={(e) => handleSelectGroup(e, 'location')} options={kitchenLocation} classNamePrefix="location" />
						</Col>
						<Col md={6}>
							<Label>Select Month</Label>
							<Select value={monthOption} onChange={(e) => handleSelectGroup(e, 'month')} options={selectMonth} classNamePrefix="month" />
						</Col>
					</Row>
				</Col>
			</Row>
		</div>
		<Row>
			<Col sm={6} lg={3}>
				<OrdersShanpshot orderDetails={{ number: 45, status: 'approved' }} />
			</Col>
			<Col sm={6} lg={3}>
				<OrdersShanpshot orderDetails={{ number: 45, status: 'pending' }} />
			</Col>
			<Col sm={6} lg={3}>
				<OrdersShanpshot orderDetails={{ number: 45, status: 'cancelled' }} />
			</Col>
			<Col sm={6} lg={3}>
				<OrdersShanpshot orderDetails={{ number: 45, status: 'inactive' }} />
			</Col>
		</Row>
		<OrderRequestItem status="approved" />
		<OrderRequestItem status="approved" />
		<OrderRequestItem status="pending" />
		<OrderRequestItem status="pending" />
		<OrderRequestItem status="inactive" />
		<OrderRequestItem status="inactive" />
		<OrderRequestItem status="cancelled" />
		<OrderRequestItem status="cancelled" />
	</Container>
}

export default OrderRequest