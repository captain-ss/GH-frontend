import React, { useState } from 'react'
import { Container, Row, Col, Table } from 'reactstrap'
import Select from "react-select";
import Switch from "react-switch"
import { Link } from 'react-router-dom';

function DiscountOffers() {
	const [switch5, setswitch5] = useState(true)
	const [selectedGroup, setselectedGroup] = useState(null)
	const optionGroup = [
		{
			options: [
				{ label: "Mustard", value: "Mustard" },
				{ label: "Ketchup", value: "Ketchup" },
				{ label: "Relish", value: "Relish" }
			]
		},
	]

	const Offsymbol = () => {
		return (
			<div
				style={{
					display: "flex",
					justifyContent: "center",
					alignItems: "center",
					height: "100%",
					fontSize: 12,
					color: "#fff",
					paddingRight: 2
				}}
			>
				{" "}
				OFF
			</div>
		);
	};

	const OnSymbol = () => {
		return (
			<div
				style={{
					display: "flex",
					justifyContent: "center",
					alignItems: "center",
					height: "100%",
					fontSize: 12,
					color: "#fff",
					paddingRight: 2
				}}
			>
				{" "}
				ON
			</div>
		);
	}

	function handleSelectGroup(selectedGroup) {
		setselectedGroup(selectedGroup);
	}

	return <Container className="page-content">
		<div className="page-title-box">
			<Row>
				<Col md={6} className="mb-3">
					<h2 className="page-title">Discount Offers</h2>
				</Col>
				<Col md={6} className="mb-3">
					<Link to="/discount-offers/add-discount-offer" className="float-end btn btn-danger">Add</Link>
				</Col>
			</Row>
			<Row>
				<Col md={6} className="mb-3">
					<input className="form-control" type="search" placeholder="Search..." />
				</Col>
				<Col md={6} className="mb-3">
					<Select value={selectedGroup} onChange={handleSelectGroup} options={optionGroup} classNamePrefix="select2-selection" />
				</Col>
			</Row>
		</div>
		<div className="table-responsive">
			<Table className="table mb-0">
				<thead className="table-light">
					<tr>
						<td></td>
						<th scope="col">Name</th>
						<th scope="col">Code</th>
						<th scope="col">Meal Plan</th>
						<th scope="col">Description</th>
						<th scope="col">Start Date</th>
						<th scope="col">End Date</th>
						<th scope="col">Duration</th>
						<th scope="col">Total Sales</th>
						<th scope="col">Total Usage</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td scope="row"><img src="/assets/icons/warning.png" alt="warning" /></td>
						<td>Keto Living</td>
						<td>UP50LIV</td>
						<td>Keto (veg)</td>
						<td>Location er...</td>
						<td>30/01/2021</td>
						<td>30/02/2021</td>
						<td>1 Month</td>
						<td>-</td>
						<td>-</td>
					</tr>
					<tr>
						<td scope="row">
							<Switch
								uncheckedIcon={<Offsymbol />}
								checkedIcon={<OnSymbol />}
								onColor="#418108"
								offColor='#5A5858'
								onChange={() => {
									setswitch5(!switch5);
								}}
								checked={switch5}
							/>
						</td>
						<td>Keto Living</td>
						<td>UP50LIV</td>
						<td>Keto (veg)</td>
						<td>Location er...</td>
						<td>30/01/2021</td>
						<td>30/02/2021</td>
						<td>1 Month</td>
						<td>0000435</td>
						<td>90</td>
					</tr>
				</tbody>
			</Table>
		</div>
	</Container>;
}

export default DiscountOffers