import React, { useState } from 'react';
import { Container, Row, Col, FormGroup, Label, Button } from 'reactstrap';
import Switch from "react-switch";
import { AvForm, AvField } from "availity-reactstrap-validation"

function AddDiscountOffer() {
	const [switch5, setswitch5] = useState(true);
	const [selectedGroup, setselectedGroup] = useState(null);
	const [textareabadge, settextareabadge] = useState(false)
	const [textcount, settextcount] = useState(0)

	const Offsymbol = () => {
		return (
			<div
				style={{
					display: "flex",
					justifyContent: "center",
					alignItems: "center",
					height: "100%",
					fontSize: 12,
					color: "#fff",
					paddingRight: 2
				}}
			>
				{" "}
				OFF
			</div>
		);
	};

	const OnSymbol = () => {
		return (
			<div
				style={{
					display: "flex",
					justifyContent: "center",
					alignItems: "center",
					height: "100%",
					fontSize: 12,
					color: "#fff",
					paddingRight: 2
				}}
			>
				{" "}
				ON
			</div>
		);
	};

	function textareachange(event) {
		const count = event.target.value.length;

		if (count > 0) {
			settextareabadge(true);
		} else {
			settextareabadge(false);
		}
		settextcount(event.target.value.length);
	}

	function handleSelectGroup(e) {
		setselectedGroup(e.target.value);
	}
	
	// function handleResetForm(e) {
	// 	console.log(document.querySelector('.frm-discount'));
	// 	document.querySelector('.frm-discount').reset();
	// }
	return <Container className="page-content add-discount-offers">
		<div className="page-title-box">
			<Row>
				<Col md={6} className="mb-3">
					<h2 className="page-title">Add Discount Offer</h2>
					<Switch
						uncheckedIcon={<Offsymbol />}
						checkedIcon={<OnSymbol />}
						onColor="#418108"
						offColor='#5A5858'
						onChange={() => {
							setswitch5(!switch5);
						}}
						checked={switch5}
					/>
				</Col>
				<Col md={6} className="mb-3">
				</Col>
			</Row>
		</div>
		<AvForm method="post" action="#" className="frm-discount needs-validation">
			<Row>
				<Col md={4} className="mb-3">
					<FormGroup className="mb-3">
						<Label htmlFor="dicount-name">Discount Name<sup>*</sup></Label>
						<AvField name="discountName" placeholder="Type here" type="text" errorMessage="Enter Discount Name" className="form-control" validate={{ required: { value: true } }} id="dicount-name" />
					</FormGroup>
				</Col>
				<Col md={4} className="mb-3">
					<FormGroup className="mb-3">
						<Label htmlFor="dicount-code">Discount code<sup>*</sup></Label>
						<AvField name="discountCode" placeholder="Type here" type="text" errorMessage="Enter Discount Code" className="form-control" validate={{ required: { value: true } }} id="dicount-code" />
					</FormGroup>
				</Col>
				<Col md={4} className="mb-3">
					<FormGroup className="mb-3">
					<Label htmlFor="meal-plan">Meal Plan<sup>*</sup></Label>
					<AvField type="select" name="mealPlan" id="meal-plan" errorMessage="Select Meal Plan" validate={{ required: { value: true } }} value={selectedGroup} onChange={handleSelectGroup}>
						<option value="">Meal Plan</option>
						<option value="weight-loss">Weight Loss</option>
						<option value="weight-loss1">Weight Loss 1</option>
						<option value="weight-loss2">Weight Loss 2</option>
						</AvField>
					</FormGroup>
				</Col>
				<Col md={4} className="mb-3">
					<FormGroup className="mb-3">
						<Label htmlFor="start-date">Start Date<sup>*</sup></Label>
						<AvField name="startDate" placeholder="DD/MM/YYYY" type="date" errorMessage="Select Start Date" className="form-control" validate={{ required: { value: true } }} id="start-date" />
					</FormGroup>
				</Col>
				<Col md={4} className="mb-3">
					<FormGroup className="mb-3">
						<Label htmlFor="end-date">End Date<sup>*</sup></Label>
						<AvField name="endDate" placeholder="DD/MM/YYYY" type="date" errorMessage="Select End Date" className="form-control" validate={{ required: { value: true } }} id="end-date" />
					</FormGroup>
				</Col>
				<Col xs={12} className="mb-3">
					<FormGroup className="textarea-badge mb-3">
						<Label htmlFor="description">Description</Label>
						<AvField type="textarea" id="description" name="description" onChange={textareachange} maxLength="200" rows="3" placeholder="Type here (max 200 words)" />
						{textareabadge ? <span className="badgecount badge badge-success">{" "}{textcount} / 200{" "}</span> : null}
					</FormGroup>
				</Col>
				<Col xs={12} className="mb-3">
					<Button type="submit" className="btn-frm btn--orange">Submit</Button>
					<Button type="reset" outline className="btn-frm">Cancel</Button>
				</Col>
			</Row>
		</AvForm>
	</Container>;
}

export default AddDiscountOffer