import React from 'react'

function AccountSettings() {
  return (
	<div>AccountSettings</div>
  )
}

export default AccountSettings