import React, { useState } from 'react';
import { Container, Row, Col, Label, Table, Button } from 'reactstrap';
import Select from "react-select"
import { Link } from 'react-router-dom';
function OrdersShanpshot({ orderDetails }) {
	const { number, status } = orderDetails;

	const handleClick = (e) => {
		const orderSnapshotCTA = document.querySelectorAll('.order-snapshot--wrapper');
		orderSnapshotCTA.forEach((obj) => {
			obj.classList.remove('active');
		})
		if (e.target.tagName !== 'button') {
			console.log('parent')
			e.target.closest('button').classList.add('active');
		}
	}

	return <Button className="order-snapshot--wrapper mb-3" data-order-status={status} onClick={handleClick}>
		<p className="order-content">
			<span className="order-no">{number}</span>
			{status === 'approved' && <span className="order-status">All Tickets</span>}
			{status === 'pending' && <span className="order-status">In-Progress Tickets</span>}
			{status === 'cancelled' && <span className="order-status">Closed Tickets</span>}

		</p>

		<div className={`status-icon ${status}`}>
			<img src={`/assets/icons/ico_${status}.png`} alt={`icon ${status}`} />
		</div>
	</Button>
}

function HelpSupport() {
	const [locationOption, setLocation] = useState(null);
	const [monthOption, setMonth] = useState(null);


	const kitchenLocation = [
		{
			options: [
				{ label: "Mustard", value: "Mustard" },
				{ label: "Ketchup", value: "Ketchup" },
				{ label: "Relish", value: "Relish" }
			]
		},
	];
	const TableData = [
		{ tickeId: "#1876GG", subject: "Problem starting campaign last week.....", status: "New", lastUpdate: "Jan 10, 2016" },
		{ tickeId: "#1876GG", subject: "Problem starting campaign last week.....", status: "In Progress", lastUpdate: "Jan 10, 2016" },
		{ tickeId: "#1876GG", subject: "Problem starting campaign last week.....", status: "Closed", lastUpdate: "Jan 10, 2016" },
		{ tickeId: "#1876GG", subject: "Problem starting campaign last week.....", status: "Closed", lastUpdate: "Jan 10, 2016" },
		{ tickeId: "#1876GG", subject: "Problem starting campaign last week.....", status: "Closed", lastUpdate: "Jan 10, 2016" },
	];

	const selectMonth = [
		{
			options: [
				{ label: "Month", value: "Month" },
				{ label: "Ketchup", value: "Ketchup" },
				{ label: "Relish", value: "Relish" }
			]
		},
	];

	function handleSelectGroup(selectedGroup, group) {
		if (group === 'location') {
			setLocation(selectedGroup);
		}
		if (group === 'month') {
			setMonth(selectedGroup);
		}
	}
	return <Container className="page-content order-request--wrapper">
		<div className="page-title-box">
			<Row className="mb-3">
				<Col md={6}>
					<h2 className="page-title">Help/Support</h2>
				</Col>
				<Col md={6}>
					<Row>
						<Col md={6}>
							<Label>Kitchen Location<sup>*</sup></Label>
							<Select value={locationOption} onChange={(e) => handleSelectGroup(e, 'location')} options={kitchenLocation} classNamePrefix="location" />
						</Col>
						<Col md={6}>
							<Label>Select Month</Label>
							<Select value={monthOption} onChange={(e) => handleSelectGroup(e, 'month')} options={selectMonth} classNamePrefix="month" />
						</Col>
					</Row>
				</Col>
			</Row>
		</div>
		<Row>
			<Col sm={6} lg={3}>
				<OrdersShanpshot orderDetails={{ number: 45, status: 'approved' }} />
			</Col>
			<Col sm={6} lg={3}>
				<OrdersShanpshot orderDetails={{ number: 45, status: 'pending' }} />
			</Col>
			<Col sm={6} lg={3}>
				<OrdersShanpshot orderDetails={{ number: 45, status: 'cancelled' }} />
			</Col>

		</Row>






		<div className="table-responsive">
			<Table className="mb-0">
				<thead className="table-light">
					<tr>
						<th scope="col">Ticket ID</th>
						<th scope="col">Subject</th>
						<th scope="col">Status</th>
						<th scope="col">Last Update	</th>
						<th scope="col"></th>
					</tr>
				</thead>
				<tbody>

					{TableData.map((data, index) => {
						return (
							<tr>
								<td>{data.tickeId}</td>
								<td>{data.subject}</td>
								{data.status == "Closed" ? (
									<td><span className='closed_tag'>{data.status}</span></td>
								) : <td>

									<select className='status-select'>
										<option>{data.status}</option>
										{data.status == "New" ? (
											<option>In Progress</option>
										) : <option>New</option>}

									</select>
								</td>
								}

								<td>{data.lastUpdate}</td>
								<td>
									<Link to="/help-support-detail">
										<Button className="btn-action">
											<i className="fas fa-chevron-circle-right"></i>
										</Button>
									</Link>
									

								</td>
							</tr>
						)

					})}


				</tbody>
			</Table>
		</div>
	</Container>
}

export default HelpSupport