import React from 'react';
import { Link } from 'react-router-dom';
import { Container, Row, Col, Button, Table } from 'reactstrap';

function MenuItems() {
	return <Container className="page-content menu-items--wrapper">
		<div className="page-title-box">
			<Row>
				<Col md={6} className="mb-3">
					<h2 className="page-title">Items</h2>
				</Col>
				<Col md={6} className="mb-3">
					<div className="float-end">
						<Button color="outline-secondary">Import</Button>
						{/* <Button color="danger" className='ms-4'>Create</Button> */}
						<Link to="/items/add-item" className="btn btn-danger ms-4">Create</Link>
					</div>
				</Col>
			</Row>
			<Row>
				<Col xs={7} className="mb-3 position-relative">
					<input className="form-control" type="search" placeholder="Search" />
					<img src="/assets/icons/search.svg" className='ico-search' />
				</Col>
				<Col xs={4} className="mb-3 position-relative">
					<input className="form-control" type="search" placeholder="Search by Category" />
					<img src="/assets/icons/search.svg" className='ico-search' />
				</Col>
			</Row>
		</div>
		<div className="table-responsive">
			<Table className="mb-0">
				<thead className="table-light">
				<tr>
					<th scope="col">Name</th>
					<th scope="col">Cost</th>
					<th scope="col">Cal count</th>
					<th scope="col">Category</th>
						<th scope="col">Action</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td className="d-flex align-items-center">
							<img src="/assets/meal-item.png" className="avatar-sm rounded-circle float-start me-3" alt="" />
							Yogurt with mixed berries | trail mix of nuts and dry ...
						</td>
						<td>34</td>
						<td>200</td>
						<td>Lunch</td>
						<td>
							<Button className="btn-action"><i className="fas fa-pencil-alt"></i></Button>
							<Button className="btn-action"><i className="fas fa-trash-alt"></i></Button>
						</td>
					</tr>
					<tr>
						<td className="d-flex align-items-center">
							<img src="/assets/meal-item.png" className="avatar-sm rounded-circle float-start me-3" alt="" />
							Yogurt with mixed berries | trail mix of nuts and dry ...
						</td>
						<td>34</td>
						<td>200</td>
						<td>Lunch</td>
						<td>
							<Button className="btn-action"><i className="fas fa-pencil-alt"></i></Button>
							<Button className="btn-action"><i className="fas fa-trash-alt"></i></Button>
						</td>
					</tr>
					<tr>
						<td className="d-flex align-items-center">
							<img src="/assets/meal-item.png" className="avatar-sm rounded-circle float-start me-3" alt="" />
							Yogurt with mixed berries | trail mix of nuts and dry ...
						</td>
						<td>34</td>
						<td>200</td>
						<td>Lunch</td>
						<td>
							<Button className="btn-action"><i className="fas fa-pencil-alt"></i></Button>
							<Button className="btn-action"><i className="fas fa-trash-alt"></i></Button>
						</td>
					</tr>
					<tr>
						<td className="d-flex align-items-center">
							<img src="/assets/meal-item.png" className="avatar-sm rounded-circle float-start me-3" alt="" />
							Yogurt with mixed berries | trail mix of nuts and dry ...
						</td>
						<td>34</td>
						<td>200</td>
						<td>Lunch</td>
						<td>
							<Button className="btn-action"><i className="fas fa-pencil-alt"></i></Button>
							<Button className="btn-action"><i className="fas fa-trash-alt"></i></Button>
						</td>
					</tr>
					<tr>
						<td className="d-flex align-items-center">
							<img src="/assets/meal-item.png" className="avatar-sm rounded-circle float-start me-3" alt="" />
							Yogurt with mixed berries | trail mix of nuts and dry ...
						</td>
						<td>34</td>
						<td>200</td>
						<td>Lunch</td>
						<td>
							<Button className="btn-action"><i className="fas fa-pencil-alt"></i></Button>
							<Button className="btn-action"><i className="fas fa-trash-alt"></i></Button>
						</td>
					</tr>
				</tbody>
			</Table>
		</div>
	</Container>
}

export default MenuItems