import React from 'react'
import { Container, Row, Col, Table } from 'reactstrap';

function Tags() {
	return <Container className="page-content tags--wrapper">
		<div className="page-title-box">
			<Row>
				<Col xs={4} className="mb-3">
					<h2 className="page-title">List of Tags</h2>
				</Col>
			</Row>
			<Row>
				<Col xs={4} className="mb-3 position-relative">
					<input className="form-control" type="search" placeholder="Search" />
					<img src="/assets/icons/search.svg" className='ico-search' />
				</Col>
			</Row>
		</div>
		<div className="table-responsive">
			<Table className="mb-0">
				<thead className="table-light">
					<tr>
						<th>Type</th>
						<th>Name</th>
						<th>Date Created</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<th scope="row">
							<img src="/assets/icons/veg-ico.svg" alt="" />
						</th>
						<td>Vegetarian</td>
						<td>1/1/2022</td>
					</tr>
					<tr>
						<th scope="row">
							<img src="/assets/icons/non-veg-ico.svg" alt="" />
						</th>
						<td>Non-vegetarian</td>
						<td>1/1/2022</td>
					</tr>
					<tr>
						<th scope="row">
							<img src="/assets/icons/veg-ico.svg" alt="" />
						</th>
						<td>Vegan</td>
						<td>1/1/2022</td>
					</tr>
					<tr>
						<th scope="row">
							<img src="/assets/icons/veg-ico.svg" alt="" />
						</th>
						<td>Gluten-free</td>
						<td>1/1/2022</td>
					</tr>
					<tr>
						<th scope="row">
							<img src="/assets/icons/non-veg-ico.svg" alt="" />
						</th>
						<td>Bone-brath</td>
						<td>1/1/2022</td>
					</tr>
					<tr>
						<th scope="row">
							<img src="/assets/icons/non-veg-ico.svg" alt="" />
						</th>
						<td>Keto</td>
						<td>1/1/2022</td>
					</tr>
				</tbody>
			</Table>
		</div>
	</Container>
}

export default Tags