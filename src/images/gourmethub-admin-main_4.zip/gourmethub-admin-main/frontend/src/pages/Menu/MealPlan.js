import React, { useState } from 'react'
import { Container, Row, Col, ButtonGroup, Button } from 'reactstrap'
import MealItemsList from 'components/MealItemsList/MealItemsList'

function MealPlan() {
	const [orderType, setOrderType] = useState('default');
	const selectOrderType = [
		{ name: 'Weekly Menu', value: 'weekly' },
		{ name: 'Default Menu', value: 'default' }
	];

	const mealItems = {
		breakfast: {
			label: 'Breakfast',
			itemList: [
				{ name: 'Yogurt with mixed berries | trail mix of nuts and dry ...', cal: '120 cal', price: 'AED 23' },
				{ name: 'Yogurt with mixed berries | trail mix of nuts and dry ...', cal: '120 cal', price: 'AED 23' },
				{ name: 'Yogurt with mixed berries | trail mix of nuts and dry ...', cal: '120 cal', price: 'AED 23' }
			]
		},
		lunch: {
			label: 'Lunch',
			itemList: [
				{ name: 'Yogurt with mixed berries | trail mix of nuts and dry ...', cal: '120 cal', price: 'AED 23' },
				{ name: 'Yogurt with mixed berries | trail mix of nuts and dry ...', cal: '120 cal', price: 'AED 23' },
				{ name: 'Yogurt with mixed berries | trail mix of nuts and dry ...', cal: '120 cal', price: 'AED 23' }
			]
		},
		dinner: {
			label: 'Dinner',
			itemList: [
				{ name: 'Yogurt with mixed berries | trail mix of nuts and dry ...', cal: '120 cal', price: 'AED 23' },
				{ name: 'Yogurt with mixed berries | trail mix of nuts and dry ...', cal: '120 cal', price: 'AED 23' },
				{ name: 'Yogurt with mixed berries | trail mix of nuts and dry ...', cal: '120 cal', price: 'AED 23' }
			]
		},
		snack1: {
			label: 'Snack 1',
			itemList: [
				{ name: 'Yogurt with mixed berries | trail mix of nuts and dry ...', cal: '120 cal', price: 'AED 23' },
				{ name: 'Yogurt with mixed berries | trail mix of nuts and dry ...', cal: '120 cal', price: 'AED 23' },
				{ name: 'Yogurt with mixed berries | trail mix of nuts and dry ...', cal: '120 cal', price: 'AED 23' }
			]
		},
		snack2: {
			label: 'Snack 2',
			itemList: [
				{ name: 'Yogurt with mixed berries | trail mix of nuts and dry ...', cal: '120 cal', price: 'AED 23' },
				{ name: 'Yogurt with mixed berries | trail mix of nuts and dry ...', cal: '120 cal', price: 'AED 23' },
				{ name: 'Yogurt with mixed berries | trail mix of nuts and dry ...', cal: '120 cal', price: 'AED 23' }
			]
		}
	};

	return <Container className="page-content tags--wrapper">
		<div className="page-title-box">
			<Row>
				<Col xs={6} className="mb-3">
					<h2 className="page-title">add Items to <span className="color-orange">Muscle Gain</span> <Button color="outline" className="btn-preview">Preview</Button></h2>
				</Col>
			</Row>
			<Row>
				<Col xs={6} className="mb-3">
					<p className="meal-plan--text">Cal Count <span>1200</span></p>
					<p className="meal-plan--text">Price <span>AED 2000</span></p>
				</Col>
				<Col xs={6} className="mb-3 menu-type--selection">
					<ButtonGroup className="float-end">
						{
							selectOrderType.map((order, idx) => <Button key={`orderType-${idx}`} color="outline" onClick={() => setOrderType(order.value)} active={orderType === order.value}>{order.name}</Button>)
						}
					</ButtonGroup>
				</Col>
			</Row>
		</div>
		<div className="meal-items-list-wrapper">
			<MealItemsList items={mealItems.breakfast} />
			<MealItemsList items={mealItems.lunch} />
			<MealItemsList items={mealItems.dinner} />
			<MealItemsList items={mealItems.snack1} />
			<MealItemsList items={mealItems.snack2} />
		</div>
		<Button color="outline" className="meal-plan-btn btn-orange">Save</Button>
		<Button color="outline" className="meal-plan-btn btn-preview">Cancel</Button>
	</Container>
}

export default MealPlan