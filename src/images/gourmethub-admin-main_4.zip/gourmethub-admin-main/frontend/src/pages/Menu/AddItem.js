import React, { useState } from 'react';
import MetaTags from 'react-meta-tags';
import Select from "react-select"
import { Container, Row, Col, FormGroup, Label, Button, Card, Form, CardBody, CardTitle, CardSubtitle } from 'reactstrap';
import Switch from "react-switch";
import { AvForm, AvField } from "availity-reactstrap-validation"
import Dropzone from "react-dropzone"
import UploadIcon from '../../assets/images/upload_button.svg';

function AddItem() {

  const [selectedGroup, setselectedGroup] = useState(null);
  const [textareabadge, settextareabadge] = useState(false)
  const [textcount, settextcount] = useState(0)
  const [selectedFiles, setselectedFiles] = useState([])
  const [selectedMulti, setselectedMulti] = useState(null)

  const optionGroup = [
    {
      label: "Picnic",
      options: [
        { label: "Mustard", value: "Mustard" },
        { label: "Ketchup", value: "Ketchup" },
        { label: "Relish", value: "Relish" }
      ]
    },
    {
      label: "Camping",
      options: [
        { label: "Tent", value: "Tent" },
        { label: "Flashlight", value: "Flashlight" },
        { label: "Toilet Paper", value: "Toilet Paper" }
      ]
    }
  ]
  function textareachange(event) {
    const count = event.target.value.length;

    if (count > 0) {
      settextareabadge(true);
    } else {
      settextareabadge(false);
    }
    settextcount(event.target.value.length);
  }

  function handleSelectGroup(e) {
    setselectedGroup(e.target.value);
  }
  function handleMulti(selectedMulti) {
    setselectedMulti(selectedMulti)
    
  }
  function handleAcceptedFiles(files) {
    files.map(file =>
      Object.assign(file, {
        preview: URL.createObjectURL(file),
        formattedSize: formatBytes(file.size),
      })
    )
    setselectedFiles(files)
  }
  function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const dm = decimals < 0 ? 0 : decimals
    const sizes = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"]

    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i]
  }

  // function handleResetForm(e) {
  // 	console.log(document.querySelector('.frm-discount'));
  // 	document.querySelector('.frm-discount').reset();
  // }
  return <Container className="page-content add-discount-offers">
    <div className="page-title-box">
      <Row>
        <Col md={12} className="mb-3">
          <h2 className="page-title">Create an Item</h2>

        </Col>

      </Row>
    </div>
    <AvForm method="post" action="#" className="frm-discount needs-validation">
      <Row>
        
          <Col md={9} className="mb-3">


            <Row>
              <Col xs={12} className="mb-3">
                <FormGroup className="textarea-badge mb-3">
                  <Label htmlFor="itemName">Item Name<sup>*</sup></Label>
                  <AvField type="textarea" id="itemName" errorMessage="Please Enter Item Name" name="itemName" validate={{ required: { value: true } }}  onChange={textareachange} maxLength="200" rows="1"  placeholder="Type here (max 200 words)" />
                  {textareabadge ? <span className="badgecount badge badge-success">{" "}{textcount} / 200{" "}</span> : null}
                </FormGroup>
              </Col>

              
                <Col xs={4} className="mb-3 position-relative">
                <label htmlFor="category">Category<sup>*</sup></label>
                <div className='position-relative'>
					<input id="category" className="form-control" type="search" placeholder="Select" />
					<img src="/assets/icons/search.svg" className='ico-search' />
          </div>
               
              </Col>

              <Col xs={12} className="mb-3">
                <FormGroup className="textarea-badge mb-3">
                  <Label htmlFor="description">Description<sup>*</sup></Label>
                  <AvField type="textarea" id="description" errorMessage="Please Enter Description" name="description" validate={{ required: { value: true } }}  onChange={textareachange} maxLength="200" rows="1"  placeholder="Type here (max 200 words)" />
                  {textareabadge ? <span className="badgecount badge badge-success">{" "}{textcount} / 200{" "}</span> : null}
                </FormGroup>
              </Col>

              <Col md={4} className="mb-3">
              <div className="mb-3">
                          <label className="control-label">
                           Tags<sup>*</sup>
                          </label>
                          <Select
                            value={selectedMulti}
                            isMulti={true}
                            onChange={() => {
                              handleMulti()
                            }}
                            options={optionGroup}
                            classNamePrefix="select2-selection"
                          />
                        </div> 
                
              </Col>



           
            </Row>

          </Col>
          <Col md={3} className="mb-3">
          <Row>
              <Col xs={12} className="mb-3">
                <FormGroup className="textarea-badge mb-3">
                  <Label htmlFor="cost">Cost<sup>*</sup></Label>
                  <AvField name="cost" placeholder="Type here" type="text" errorMessage="Please Select Category" className="form-control" validate={{ required: { value: true } }} id="cost" />
                </FormGroup>
              </Col>
              <Col xs={12} className="mb-3">
                <FormGroup className="mb-3">
                  <Label htmlFor="sku">SKU</Label>
                  <AvField name="sku" placeholder="Type here" type="text" errorMessage="Please Select Category" className="form-control" validate={{ required: { value: true } }} id="sku" />
                </FormGroup>
              </Col>

              <Col xs={12} className="mb-3">
                <FormGroup className="textarea-badge mb-3">
                  <Label htmlFor="cal-count">Cal Count<sup>*</sup></Label>
                  <AvField name="cal-count" placeholder="Type here" type="text" errorMessage="Enter Cal Count" className="form-control" validate={{ required: { value: true } }} id="cal-count" />                </FormGroup>
              </Col>

              
            </Row>
          </Col>
      </Row>
      <Row>
            <Col className="col-12">
               
                
                  <CardTitle className="h4">Upload Photo<sup>*</sup></CardTitle>
                  
                  <div className="mb-5">
                    <Form>
                      <Dropzone
                        onDrop={acceptedFiles => {
                          handleAcceptedFiles(acceptedFiles)
                        }}
                      >
                        {({ getRootProps, getInputProps }) => (
                          <div className="dropzone">
                            <div
                              className="dz-message needsclick"
                              {...getRootProps()}
                            >
                              <input {...getInputProps()} />
                              <div>
                                <img src={UploadIcon} className="img-fluid"></img>
                              </div>
                              <h4>Drag and drop your file <br/> or</h4>
                              <Button className="btn-frm btn--orange">Choose file</Button>
                            </div>
                          </div>
                        )}
                      </Dropzone>
                      <div className="dropzone-previews mt-3" id="file-previews">
                        {selectedFiles.map((f, i) => {
                          return (
                            <Card
                              className="mt-1 mb-0 shadow-none border dz-processing dz-image-preview dz-success dz-complete"
                              key={i + "-file"}
                            >
                              <div className="p-2">
                                <Row className="align-items-center">
                                  <Col className="col-auto">
                                    <img
                                      data-dz-thumbnail=""
                                      height="80"
                                      className="avatar-sm rounded bg-light"
                                      alt={f.name}
                                      src={f.preview}
                                    />
                                  </Col>
                                  <Col>
                                    <Link
                                      to="#"
                                      className="text-muted font-weight-bold"
                                    >
                                      {f.name}
                                    </Link>
                                    <p className="mb-0">
                                      <strong>{f.formattedSize}</strong>
                                    </p>
                                  </Col>
                                </Row>
                              </div>
                            </Card>
                          )
                        })}
                      </div>
                    </Form>
                  </div>
                
               
              
            </Col>
            <Col xs={12} className="mb-3">
                <Button type="submit" className="btn-frm btn--orange">Save</Button>
                <Button type="reset" outline className="btn-frm">Cancel</Button>
              </Col>
          </Row>
    </AvForm>
  

  </Container>;
}

export default AddItem;