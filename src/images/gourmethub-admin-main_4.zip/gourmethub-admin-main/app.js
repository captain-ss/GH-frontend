import "@progress/kendo-theme-material/dist/all.css";
import DateComponent from "./component/datecomponent";


function App() {
  return (
    <div className="App">

      <DateComponent />
    </div>
  );
}



export default App;
