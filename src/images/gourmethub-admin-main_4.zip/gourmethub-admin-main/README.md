# gourmethub-admin
Gourmet Hub Admin

## Available Scripts

In the project directory, you can run:

### `npm server`

Runs the app in the debug mode.\
Open [http://localhost:5500](http://localhost:5500) to view it in your browser.

The app will reload when you make changes.\
You may also see any lint errors in the console.

### `npm start`

Runs the Client (serving `frontend` folder) in the in development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

### `npm deploy`

It will build the app from `frontend` folder and runs the app in the in production mode.\
Open [http://localhost:5500](http://localhost:5500) to view it in your browser.
